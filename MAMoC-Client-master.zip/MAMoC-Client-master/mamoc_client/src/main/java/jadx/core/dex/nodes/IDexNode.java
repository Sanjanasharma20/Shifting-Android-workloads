package jadx.core.dex.nodes;

public interface IDexNode {

	String typeName();

	DexNode dex();

	RootNode root();
}

