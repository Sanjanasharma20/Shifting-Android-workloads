package io.crossbar.autobahn.websocket.messages;

/// Quit background thread.
public class Quit extends Message {

}
