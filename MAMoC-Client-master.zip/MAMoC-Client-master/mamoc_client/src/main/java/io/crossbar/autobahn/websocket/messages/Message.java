package io.crossbar.autobahn.websocket.messages;

public class Message {
}
